<?php
session_start();
require_once('config.php');
require_once('shorter_text.php');
if ($_SESSION) {
	
?>
<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<title>File Holder</title>
	<meta name="description" content="Project CodeWeek - 'File Hoder'">
	<meta name="author" content="">
	<link rel="icon" type="image/png" href="images/favicon.png">

	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style-dashboard.css">
	<link rel="stylesheet" href="css/scrolling-nav.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">

	<!-- ............................ START JUMBOTRON ............................-->

</head>
<body>


		<nav class="navbar navbar-default fixed cl-effect-14">
		  <div class="container-fluid">
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
				<a class="navbar-brand" href="index.php">Brand</a>
		    </div>

		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      <ul class="nav navbar-nav">
		       <li class="active"><a href="dashboard.php">Dashboard<span class="sr-only">(current)</span></a></li>
				<li><a href="file-upload.php">Upload Files</a></li>
				<li><a href="all-users.php">All Users</a></li>
				<li><a href="logout.php">Exit</a></li>
		      </ul>
		    </div>
		  </div>
		</nav>  <!-- end navigation -->

		
<!-- ............................ START SIDEBAR ............................ -->


<div class="sidebar">
	<div class="row">
		<?php
			$s_user_info = "SELECT * FROM users WHERE user_name = '$_SESSION[user]'";
			$query_infou = mysqli_query($connect, $s_user_info) or die(mysqli_error());
			$row_uinfo = mysqli_fetch_assoc($query_infou);
		?>
		<div class="col-md-3 text-center profile">
			<img src="<?php echo $row_uinfo['pic']; ?>" alt="Avatar Male">
			<h1><?php echo $row_uinfo['full_name']; ?></h1>
			<h3>Age: <?php echo $row_uinfo['age']; ?> | <?php echo $row_uinfo['sex']; ?></h3>
			<p><?php echo $row_uinfo['description']; ?></p><br/>
			<a class="btn btn-info addfile" href="file-upload.php" role="button">Add File</a>
			<a class="btn btn-info logout" href="logout.php" role="button">Exit</a><br/>	
		</div>
		
		<div class="col-md-9 files">
	
			<h2>My Files: </h2><br/>

			<a href="file-upload.php">
			<img src="images/dashboard/file-types/add.png" alt="Add File">
			<h3>Add file</h3>
			</a>
			<?php
				$selU = "SELECT id FROM users WHERE user_name = '$_SESSION[user]'";
				$qU = mysqli_query($connect, $selU) or die(mysqli_error());
				$row_user_id = mysqli_fetch_assoc($qU);
				$u = $row_user_id['id'];
				$sel_all_my_files = "SELECT * FROM files WHERE id_user = '$u'";
				$query_files = mysqli_query($connect, $sel_all_my_files) or die(mysqli_error());
				if (mysqli_num_rows($query_files) > 0) {
					while ($r = mysqli_fetch_assoc($query_files)) {

					
			?>
			<a href="<?php echo $r['file_dir']; ?>">
			<?php
				switch ($r['file_type']) {
					case 'image/jpeg':
						echo '<img src="images/dashboard/file-types/pic.png" alt="echo $r[file_name]; ">';
						break;
						case 'image/png':
						echo '<img src="images/dashboard/file-types/pic.png" alt="echo $r[file_name]; ">';
						break;
						case 'application/zip':
						echo '<img src="images/dashboard/file-types/rar.png" alt="echo $r[file_name]; ">';
						break;
						case 'application/x-rar-compressed':
						echo '<img src="images/dashboard/file-types/rar.png" alt="echo $r[file_name]; ">';
						break;
						case 'application/gzip':
						echo '<img src="images/dashboard/file-types/rar.png" alt="echo $r[file_name]; ">';
						break;
						case 'application/msword':
						echo '<img src="images/dashboard/file-types/doc.png" alt="echo $r[file_name]; ">';
						break;
						case 'text/html':
						echo '<img src="images/dashboard/file-types/html.png" alt="echo $r[file_name]; ">';
						break;
						case 'application/vnd.openxmlformats-officedocument.word':
						echo '<img src="images/dashboard/file-types/pdf.png" alt="echo $r[file_name]; ">';
						break;
						case 'application/octet-stream':
						echo '<img src="images/dashboard/file-types/ppt.png" alt="echo $r[file_name]; ">';
						break;
						case 'application/download':
						echo '<img src="images/dashboard/file-types/html.png" alt="echo $r[file_name]; ">';
						break;
					
					default:
						# code...
						break;
				}
			?>
			
			<h3><?php echo shorter($r['file_name'], 10); ?></h3>
			</a>
			<?php 

					}
				}
			?>
			<!--
			<a href="#">
			<img src="images/dashboard/file-types/pic.png" alt="Add File">
			<h3>Picture file</h3>
			</a>

			<a href="#">
			<img src="images/dashboard/file-types/ppt.png" alt="Add File">
			<h3>Presentation</h3>
			</a>

			<a href="#">
			<img src="images/dashboard/file-types/rar.png" alt="Add File">
			<h3>RAR Archive</h3>
			</a>

			<a href="#">
			<img src="images/dashboard/file-types/pic.png" alt="Add File">
			<h3>Pic file</h3>
			</a>

			<a href="#">
			<img src="images/dashboard/file-types/rar.png" alt="Add File">
			<h3>RAR file</h3>
			</a>

			<a href="#">
			<img src="images/dashboard/file-types/ppt.png" alt="Add File">
			<h3>PPT file</h3>
			</a>
			-->
		</div>

			


		</div>


	</div>
</div>



<!-- ............................ END PROJECT ............................ -->


	<script src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
	<script>new WOW().init();</script>
	<script src="js/scrolling-nav.js"></script>
	<script src="js/jquery.easing.min.js"></script>

</body>
</html>
<?php
}else{
	header('location: index.php');
}
?>