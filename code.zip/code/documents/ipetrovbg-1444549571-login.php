<?php 
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'documents');
if (!$conn) {
	die("Connection failed: mysqli_connect_error()"); 
} else {
	//echo "Connected successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Log in</title>
</head>
<body>
<form action="login.php" method="post">
	<label for="usrname">Username</label>
	<input type="text" name="user_name" id="usrname">
	<label for="psw">Password</label>
	<input type="password" name="password">
	<input type="submit" name="submit" value="login">
</form>
<?php 
if (!empty($_POST)) {
	$_SESSION['user_name'] = $_POST['user_name'];
	$_SESSION['password'] = $_POST['password'];
	$username = $_SESSION['user_name'];
	$password_query ="SELECT password FROM users WHERE user_name = '$username'";
	$password_result = mysqli_query($conn, $password_query);
	$password_row = mysqli_fetch_assoc($password_result);
	if ($password_row['password'] !== $_SESSION['password']) {
		echo "Wrong username or password!";
	} else {
		header('Location: welcome.php');
	}
}
?>
<a href="logout.php">Log out</a>
</body>
</html>