<?php
session_start();
require_once('config.php');
if ($_SESSION) {

	// взимаме ид от потребителската сесия
	$getIdselect = "SELECT * FROM users WHERE user_name = '$_SESSION[user]'";
	$queryget = mysqli_query($connect, $getIdselect) or die(mysqli_error());
	$rowget = mysqli_fetch_assoc($queryget);
	
	if (isset($_POST['upload'])) {
		if(!empty($_FILES)){
			if (!empty($_FILES['file']['tmp_name'])) {
				
				$file_name = $_POST['file_name'];
				$file_tmp = $_FILES['file']['tmp_name'];
				$file_type = $_FILES['file']['type'];
				$file = $_SESSION['user'].'-'.time().'-'.$_FILES['file']['name'];
				$new_file = 'documents/'.$file;
				echo $file_name;
				if (strlen($file_name) != null) {
					$reg_q = "INSERT INTO `files` (`file_name`, `file_dir`, `file_type`, `id_user`)
					VALUES 
					('$file_name','$new_file', '$file_type', '$rowget[id]')";
					
					if (mysqli_query($connect, $reg_q)) {

						echo "Successful uploaded! <br />";
						move_uploaded_file($file_tmp, $new_file);


					}else{
						echo 'something wrong';
					}
				}
			}
		}
	}

?>
<form method="post" action="" enctype="multipart/form-data">
	<input type="file" name="file" /><br />
	<input type="text" name="file_name" /><br />
	<input type="submit" name="upload" value="UPLOAD">

</form>
<?php
	}
?>