<?php
session_start();
require_once('config.php');
if ($_SESSION) {
	

?>
<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<title>All Users</title>
	<meta name="description" content="Project CodeWeek - 'File Hoder'">
	<meta name="author" content="">
	<link rel="icon" type="image/png" href="images/favicon.png">

	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style-all-users.css">
	<link rel="stylesheet" href="css/scrolling-nav.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">

	<!-- ............................ START JUMBOTRON ............................-->

</head>
<body>


	<nav class="navbar navbar-default fixed cl-effect-14">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Brand</a>
			</div>

			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li><a href="dashboard.php">Dashboard <span class="sr-only">(current)</span></a></li>
					<li class="active"><a href="all-users.php">All Users</a></li>
					<li><a href="logout.php">Exit</a></li>
				</ul>
			</div>
		</div>
	</nav>  <!-- end navigation -->


	<!-- ............................ START SIDEBAR ............................ -->


	<div class="sidebar">
		<div class="row">
			<?php
				$s_user_info = "SELECT * FROM users WHERE user_name = '$_SESSION[user]'";
				$query_infou = mysqli_query($connect, $s_user_info) or die(mysqli_error());
				$row_uinfo = mysqli_fetch_assoc($query_infou);
			?>
			<div class="col-md-3 text-center profile">
				<img src="<?php echo $row_uinfo['pic']; ?>" alt="<?php echo $row_uinfo['full_name']; ?>">
				<h1><?php echo $row_uinfo['full_name']; ?></h1>
				<h3>Age: <?php echo $row_uinfo['age']; ?> | <?php echo $row_uinfo['sex']; ?></h3>
				<p><?php echo $row_uinfo['description']; ?></p><br/>
				<a class="btn btn-info update" href="dashboard.php" role="button">Dashboard</a><br/>
				<a class="btn btn-info update" href="logout.php" role="button">log Out</a><br/>
			</div>

			<div class="col-md-9 files">

				<h2>All Users: </h2><br/>
				<div>
					<!-- Nav tabs -->
					<ul class="nav nav-tabs" role="tablist">
						<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Male Users</a></li>
						<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Female Users</a></li>
					</ul>

					<!-- Tab panes -->
					<div class="tab-content">
						<div role="tabpanel" class="tab-pane active" id="home">
							<div class="row users">
							<?php 
								$male='SELECT *, COUNT(`files`.`id`) as `fm` FROM `users` 
								LEFT JOIN `files` ON `users`.`id` = `files`.`id_user`

								WHERE sex="male"
								GROUP BY `users`.`id`';
								$query_male=mysqli_query($connect, $male);
								if(mysqli_num_rows($query_male)>0){
									while($r=mysqli_fetch_assoc($query_male)){
										?>
								<div class="col-md-4">
									<a href="#" class="a-holder">
										<img src="<?php echo $r['pic'] ?>" alt="Avatar Thumbnail">
										<h4><?php echo $r['user_name'] ?></h4>
										<p class="full-name"><?php echo $r['full_name'] ?></p>
										<p class="age">Age: <?php echo $r['age'] ?></p>
										<a href="#" class="link"><?php echo $r['fm']; ?> Files</a>
									</a>
								</div>
								<?php

									}
								}
							
								?>

								


							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="profile">
							<div class="row users">

								<?php 
									$fmale='SELECT *, COUNT(`files`.`id`) as `ff` FROM `users` 
									LEFT JOIN `files` ON `users`.`id` = `files`.`id_user`

									WHERE `users`.`sex`="female"
									GROUP BY `users`.`id`';
									$query_fmale=mysqli_query($connect, $fmale);
									if(mysqli_num_rows($query_fmale)>0){
										while($rf=mysqli_fetch_assoc($query_fmale)){
								?>
								<div class="col-md-4">
									<a href="#" class="a-holder">
										<img src="<?php echo $rf['pic'] ?>" alt="Avatar Thumbnail">
										<h4><?php echo $rf['user_name'] ?></h4>
										<p class="full-name"><?php echo $rf['full_name'] ?></p>
										<p class="age">Age: <?php echo $rf['age'] ?></p>
										<a href="#" class="link"><?php echo $rf['ff']; ?> Files</a>
									</a>
								</div>
								<?php

									}
								}
							
								?>


								

							</div>
						</div>
					</div>
				</div>



				<!-- ............................ END PROJECT ............................ -->


				<script src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
				<script src="js/bootstrap.min.js"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
				<script>new WOW().init();</script>
				<script src="js/scrolling-nav.js"></script>
				<script src="js/jquery.easing.min.js"></script>

			</body>
			</html>

<?php
	}else{
		header('location: index.php');
	}
?>