-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Време на генериране: 11 окт 2015 в 22:24
-- Версия на сървъра: 5.6.20-68.0-log
-- Версия на PHP: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `fileho8_documents`
--

-- --------------------------------------------------------

--
-- Структура на таблица `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_dir` varchar(255) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Схема на данните от таблица `files`
--

INSERT INTO `files` (`id`, `file_name`, `file_dir`, `file_type`, `id_user`) VALUES
(1, 'First file', 'documents/ipetrovbg-1444582609-Demo.zip', 'application/zip', 22),
(2, 'Second file', 'documents/ipetrovbg-1444582636-vtatsa-balkan.jpg', 'image/jpeg', 22),
(3, 'new', 'documents/ipetrovbg-1444583015-1.-OOP-Intro-homework.docx', 'application/vnd.openxmlformats-officedocument.word', 22),
(4, 'Някакво име', 'documents/natalia-1444584394-Untitled 1.ppt', 'application/octet-stream', 24),
(5, 'Снимка', 'documents/natalia-1444584419-2015-10-11 17.23.23.jpg', 'image/jpeg', 24),
(6, 'Test1', 'documents/radi1-1444587893-10409362_10200280175082425_3060510904999939048_n.jpg', 'image/jpeg', 27),
(7, 'me.jpg', 'documents/radi1-1444588150-IMG_20150718_074420.jpg', 'image/jpeg', 27),
(8, 'sql', 'documents/ipetrovbg-1444589498-documents.sql', 'application/octet-stream', 22),
(9, 'Hackaton Vratsa Team', 'documents/ipetrovbg-1444589572-2015-10-11 17.23.23.jpg', 'image/jpeg', 22);

-- --------------------------------------------------------

--
-- Структура на таблица `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `pic` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Схема на данните от таблица `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `full_name`, `description`, `age`, `sex`, `pic`) VALUES
(22, 'ipetrovbg', 'ad95e8df42ecd59347b71b04ccce8de6d04e1090', 'Петър Петров', '		Some description', 26, 'male', 'pics/ipetrovbg-1444582564-10647025_10203374344943883_9150976265850950944_n.jpg'),
(23, 'milenski64', '5e7f9c607617ef1eebf24487f0586e8394ee8439', 'Milen Tsolov', 'I love my Hackathon Vratsa team! ', 17, 'male', 'pics/milenski64-1444582977-IMG_7716.JPG'),
(24, 'natalia', '2298625f2ba17912b286ad9afd8f089e460241b9', 'Наталия Петрова', '		something', 29, 'female', 'pics/natalia-1444584338-pr.jpg'),
(25, 'tsoko', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Marios Pittas', '		Hey', 21, 'female', 'pics/tsoko-1444585964-12072802_1509397332710805_6911096178009767546_n.jpg'),
(27, 'radi1', '51be4c7594eb6986596c8cb128cecacdc50d6e21', 'RD', '		Dano da stane.', 29, 'male', 'pics/radi-1444587344-1619635_4996734771542_1772461771928273331_n.jpg');

--
-- Ограничения за дъмпнати таблици
--

--
-- Ограничения за таблица `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
